
from itertools import chain
import pandas as pd
from random import randint
from sqlalchemy.orm import Session

from modules.utilities.aws.rds.initialize.db_initializer import initialize_db
from tests.etl.test_configs import test_configs
from modules.utilities.aws.rds.query.model_helper import get_pk_id_from_record
from modules.utilities.aws.rds.query.query_helper import get_record_from_db
from modules.utilities.generic.os_helper import get_output_path
from tests.etl.helpers.metrics_helper import get_metric_errors


def test_dataset_type(project, year, data_type, n=5):
    engine = initialize_db(overwrite=False)
    test_config = test_configs[project][data_type]
    df_raw = sample_raw_data(test_config, project, year, n)
    errors_2d = df_raw.apply(lambda row: test_single_row(
        engine, test_config, row), axis=1)
    errors = list(chain.from_iterable(errors_2d))
    return errors


def test_single_row(engine, test_config, raw_row):
    session = Session(engine)
    db_record = get_db_record(session, test_config, raw_row)
    errors = compare_objects(test_config, raw_row, db_record)
    session.close()
    return errors


def compare_objects(test_config, raw_row, db_record):
    errors = []
    model = test_config['main_model']
    pk_id = get_pk_id_from_record(model, db_record)
    errors += get_metric_errors(test_config, raw_row, db_record, pk_id)
    return errors


def get_db_record(session, test_config, raw_row):
    db_records = []
    for key_col in test_config['key_cols']:
        raw_pk_value = raw_row[key_col['raw']]
        record_pk_key = key_col['db']
        filter = {record_pk_key: raw_pk_value}
        db_record = get_record_from_db(
            session, filter, test_config['main_model'])
        db_records.append(db_record)
    result = [i for i in db_records if i != None][0]
    return result


def sample_raw_data(test_config, project, year, n=50):
    file_name = test_config['file_name']
    path = f"{get_output_path()}{project}\\{year}\\{file_name}.csv"
    df = pd.read_csv(path)
    return df.sample(n)


def get_test_row(test_config, project, year):
    df = sample_raw_data(test_config, project, year)
    rand_i = randint(0, df.shape[0])
    return df.iloc[rand_i]
