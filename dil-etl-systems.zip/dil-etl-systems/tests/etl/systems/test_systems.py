from tests.etl.helpers.compare_helper import test_dataset_type


def test_systems():
    project = "systems"
    year = 2018
    n = 50
    hospital_errors = test_dataset_type(project, year, "hospital", n)
    print("count hospital_errors: ", len(hospital_errors))
    
    health_system_errors = test_dataset_type(project, year, "health_system", n)
    print("count health_system_errors: ", len(health_system_errors))
    
    state_errors = test_dataset_type(project, year, "state", n)
    print("count state_errors: ", len(state_errors))
    
    
if __name__ == "__main__":
    test_systems()
    