from fuzzywuzzy import process
from sqlalchemy.orm import Session

def get_primary_col_errors(engine, test_config, raw_row, pk_id):
    # threshold = 80
    # best_match = process.extractOne(key, db_keys)
    
    pass

    # id_cols = [i for i in raw_cols if i.endswith("_id")]