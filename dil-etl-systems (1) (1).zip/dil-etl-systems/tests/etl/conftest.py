import numpy as np
import pandas as pd
import pytest
from pytest_mock import MockerFixture


@pytest.fixture
def config():
    # return load_raw_config()
    pass


