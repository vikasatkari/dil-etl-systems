systems_state_metric_cont_cols = [
    'NumHospTot',
    'NumHospInSys',
    'NumAcuteHosp',
    'NumAcuteHospInSys',
    'NumSysWHospInstate',
    'NumSysHqInstate',
    "PctHospInSys",
    "PctAcuteHospInSys",
    "PctBedsInSys",
    "PctDschInSys",
    "NpPctInSys",
    "PaPctInSys",
]